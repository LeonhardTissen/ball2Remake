Ball2 (Windows 95/98/Me)

Arrow key(Joystick)...Move
[Z](A button).........Small bound

A ball is bounding freely.
When you take all diamonds, the door opens.
When you go there, the level is complete.

--------------------------------------
http://park15.wakwak.com/~n_i/fs/
pigmhall@hotmail.com
--------------------------------------
